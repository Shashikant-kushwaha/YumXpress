/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yumxpress.pojo;

/**
 *
 * @author shashikant kushwaha
 */
public class CustomerPojo {

    public CustomerPojo(){
        
    }
    
    public CustomerPojo(String customerId, String customerName, String emaildId, String password, String MobileNo, String address) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.emailId = emailId;
        this.password = password;
        this.MobileNo = MobileNo;
        this.address = address;
    }
    
    private String customerId;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String MobileNo) {
        this.MobileNo = MobileNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    private String customerName;
    private String emailId;
    private String password;
    private String MobileNo;
    private String address;
    
}
